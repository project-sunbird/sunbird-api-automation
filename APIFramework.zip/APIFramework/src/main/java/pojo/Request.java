package pojo;

import java.util.HashMap;
import java.util.Map;

public class Request {
    private Content content;


    public Content getContent() {
        return content;
    }

    public void setContent(Content content) {
        this.content = content;
    }


}
