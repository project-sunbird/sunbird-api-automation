package pojo;

import java.util.HashMap;
import java.util.Map;

public class updateRequest {
    private updateContentRequest content;


    public updateContentRequest getContent() {
        return content;
    }

    public void setContent(updateContentRequest content) {
        this.content = content;
    }


}
