package pojo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class createContent {

	private Request request;


	public Request getRequest() {
		return request;
	}

	public void setRequest(Request request) {
		this.request = request;
	}


}