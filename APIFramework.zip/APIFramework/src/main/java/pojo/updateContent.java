package pojo;

import java.util.HashMap;
import java.util.Map;

public class updateContent {
	private updateRequest request;


	public updateRequest getRequest() {
		return request;
	}

	public void setRequest(updateRequest request) {
		this.request = request;
	}



}
